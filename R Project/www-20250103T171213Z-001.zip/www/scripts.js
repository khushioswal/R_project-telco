document.addEventListener('DOMContentLoaded', function() {
  
  // Function to handle the display of content
  function showContent(contentId) {
    // Hide all content sections
    document.querySelectorAll('.content-section').forEach(section => {
      section.classList.remove('fade-in');
      section.classList.add('fade-out');
    });

    // Show the specific content section based on contentId
    const content = document.getElementById(contentId);
    if (content) {
      content.classList.remove('fade-out');
      content.classList.add('fade-in');
    }
  }

  // Add event listener for the side panel 'Learn More' button
  const sidePanelLearnMore = document.querySelector('.learn-more-side-panel');
  if (sidePanelLearnMore) {
    sidePanelLearnMore.addEventListener('click', function() {
      // Automatically load 'About the Project' content
      showContent('content_about_project');
    });
  }

  // Add event listener for the 'Learn More' CTA button
  const ctaLearnMore = document.querySelector('.learn-more-cta-button');
  if (ctaLearnMore) {
    ctaLearnMore.addEventListener('click', function() {
      // Automatically load 'About the Project' content
      showContent('content_about_project');
    });
  }

  // Add event listeners for navigation buttons
  document.querySelectorAll('.nav-button').forEach(button => {
    button.addEventListener('click', function() {
      const contentId = button.getAttribute('data-content'); // Use data-content attribute to map button to content
      showContent(contentId);
    });
  });

  // Automatically load 'About the Project' content when the page loads
  showContent('content_about_project');
});

// Add CSS for fade-in/fade-out effects dynamically
document.styleSheets[0].insertRule(`
  .fade-in {
    opacity: 1;
    transition: opacity 0.5s ease-in-out;
  }
`, 0);

document.styleSheets[0].insertRule(`
  .fade-out {
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
  }
`, 0);
$(document).ready(function () {
  // Default: Show "About the Project" content
  $('#content_about_project').fadeIn(); // Ensure it is visible on page load

  // Button click to show the respective content
  $('.nav-button').on('click', function () {
    const contentId = $(this).attr('id').replace('_btn', ''); // Map button ID to content ID
    $('.hidden-content').fadeOut(200); // Hide all content
    $(`#content_${contentId}`).fadeIn(300); // Show the selected content
  });
});
